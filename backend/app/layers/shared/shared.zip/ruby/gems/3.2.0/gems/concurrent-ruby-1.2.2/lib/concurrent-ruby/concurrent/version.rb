module Concurrent
  VERSION = '1.2.2'
end
