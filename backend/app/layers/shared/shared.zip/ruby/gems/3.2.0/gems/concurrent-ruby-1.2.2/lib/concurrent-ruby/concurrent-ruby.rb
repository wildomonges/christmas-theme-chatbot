# This file is here so that there is a file with the same name as the gem that
# can be required by Bundler.require. Applications should normally
# require 'concurrent'.

require_relative "concurrent"
