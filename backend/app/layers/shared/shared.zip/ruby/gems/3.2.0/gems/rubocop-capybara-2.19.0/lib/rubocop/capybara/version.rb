# frozen_string_literal: true

module RuboCop
  module Capybara
    # Version information for the Capybara RuboCop plugin.
    module Version
      STRING = '2.19.0'
    end
  end
end
