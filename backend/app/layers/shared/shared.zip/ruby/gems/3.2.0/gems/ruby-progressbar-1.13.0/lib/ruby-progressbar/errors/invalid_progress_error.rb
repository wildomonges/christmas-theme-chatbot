class   ProgressBar
class   InvalidProgressError < RuntimeError
end
end
