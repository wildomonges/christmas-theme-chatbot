class ProgressBar
  VERSION = '1.13.0'.freeze
end
