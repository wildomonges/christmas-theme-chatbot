#ifndef PSYCH_PARSER_H
#define PSYCH_PARSER_H

void Init_psych_parser(void);

#endif
