# frozen_string_literal: true

module Rainbow
  VERSION = "3.1.1"
end
