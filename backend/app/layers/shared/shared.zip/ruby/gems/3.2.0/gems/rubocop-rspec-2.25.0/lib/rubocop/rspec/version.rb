# frozen_string_literal: true

module RuboCop
  module RSpec
    # Version information for the RSpec RuboCop plugin.
    module Version
      STRING = '2.25.0'
    end
  end
end
