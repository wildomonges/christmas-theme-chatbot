require 'ruby-progressbar/refinements/progress_enumerator'
